package com.example.flutter_netflix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
